<?php
class Excellence_Ship_Block_Ship extends Mage_Core_Block_Template
{
	
}